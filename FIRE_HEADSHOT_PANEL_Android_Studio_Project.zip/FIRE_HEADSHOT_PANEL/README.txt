FIRE HEADSHOT PANEL — Android Studio project

How to build an APK:
1. Install Android Studio on a computer.
2. Open this extracted FIRE_HEADSHOT_PANEL folder.
3. Allow Gradle sync to finish (internet is needed for Android Gradle Plugin).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

This is a fair-play companion guide. It does not modify Free Fire MAX or automate gameplay.
