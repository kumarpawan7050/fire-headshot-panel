package com.fireheadshot.panel;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF090909);
        getWindow().setNavigationBarColor(0xFF090909);
        setContentView(R.layout.activity_main);
    }
}
